int service_listen_socket (const int s);
