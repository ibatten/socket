int service_client_socket (const int s, const char *const address);
